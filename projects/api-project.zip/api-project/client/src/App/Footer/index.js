import React from "react"; 

function Footer(props){
        return (
            <footer>
                <h4 className="footerpara">© Laney Kawaguchi 2018 React-Redux </h4>
            </footer>
        )
}

export default Footer; 
import React from "react"; 

function About(props){
    return (
        <div>
            <h1>This project is a cool lil' thing to get some info on Superheroes.</h1>
            <img src="https://scontent-dfw5-1.xx.fbcdn.net/v/t1.0-9/12063340_10153334167353218_3865452400818389589_n.jpg?_nc_cat=0&oh=de831bcf2ae650ef13ce590c18412cb9&oe=5B6C90E0" alt=""/>
            <p className="aboutpara" >Dedicted to my best friend Kenny Smith... Comic Book Guru and creator of "WE ARE ALL GEEKS".</p>
        </div>
    )
}

export default About; 